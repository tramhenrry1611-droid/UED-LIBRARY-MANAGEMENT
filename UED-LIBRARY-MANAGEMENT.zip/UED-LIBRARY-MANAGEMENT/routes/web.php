<?php
/**
 * Khai báo route: [phương thức, đường dẫn, Controller, hàm]
 * {id} là tham số động, được truyền vào hàm của Controller.
 */

return [
    // ----- Xác thực (AuthController) -----
    ['GET',  '/',         'AuthController', 'home'],
    ['GET',  '/login',    'AuthController', 'showLogin'],
    ['POST', '/login',    'AuthController', 'login'],
    ['GET',  '/register', 'AuthController', 'showRegister'],
    ['POST', '/register', 'AuthController', 'register'],
    ['GET',  '/logout',   'AuthController', 'logout'],

    // ----- Quản trị tài khoản + phân quyền (AdminController) -----
    ['GET',  '/admin/users',               'AdminController', 'users'],
    ['GET',  '/admin/users/{id}/edit',     'AdminController', 'editUser'],
    ['POST', '/admin/users/{id}/update',   'AdminController', 'updateUser'],
    ['POST', '/admin/users/{id}/role',     'AdminController', 'updateRole'],
    ['POST', '/admin/users/{id}/status',   'AdminController', 'updateStatus'],
    ['POST', '/admin/users/{id}/delete',   'AdminController', 'deleteUser'],

    // ----- Thông tin tài khoản sinh viên (StudentController) -----
    ['GET',  '/student/profile', 'StudentController', 'profile'],
    ['POST', '/student/profile', 'StudentController', 'updateProfile'],

    // ----- Thông tin tài khoản giảng viên (TeacherController) -----
    ['GET',  '/teacher/profile', 'TeacherController', 'profile'],
    ['POST', '/teacher/profile', 'TeacherController', 'updateProfile'],
];
