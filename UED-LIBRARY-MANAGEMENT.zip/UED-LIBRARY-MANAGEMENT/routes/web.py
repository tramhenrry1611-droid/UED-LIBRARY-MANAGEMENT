from app.Controllers.borrow_controller import borrow_bp

def register_routes(app):
    app.register_blueprint(borrow_bp)