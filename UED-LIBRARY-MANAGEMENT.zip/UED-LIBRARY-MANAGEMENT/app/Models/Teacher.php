<?php
/**
 * Model Teacher - thông tin riêng của giảng viên, bảng `teachers`.
 */
class Teacher
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function findByUserId(int $userId): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM teachers WHERE user_id = :user_id LIMIT 1');
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetch() ?: null;
    }

    public function codeExists(string $code, ?int $exceptUserId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM teachers WHERE teacher_code = :code';
        $params = ['code' => $code];
        if ($exceptUserId !== null) {
            $sql .= ' AND user_id <> :user_id';
            $params['user_id'] = $exceptUserId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn() > 0;
    }

    public function create(int $userId, array $data): bool
    {
        $stmt = $this->db->prepare(
            'INSERT INTO teachers (user_id, teacher_code, department, phone)
             VALUES (:user_id, :teacher_code, :department, :phone)'
        );
        return $stmt->execute([
            'user_id'      => $userId,
            'teacher_code' => $data['teacher_code'],
            'department'   => $data['department'] ?? null,
            'phone'        => $data['phone'] ?? null,
        ]);
    }

    public function updateByUserId(int $userId, array $data): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE teachers SET department = :department, phone = :phone WHERE user_id = :user_id'
        );
        return $stmt->execute([
            'department' => $data['department'] ?? null,
            'phone'      => $data['phone'] ?? null,
            'user_id'    => $userId,
        ]);
    }
}
