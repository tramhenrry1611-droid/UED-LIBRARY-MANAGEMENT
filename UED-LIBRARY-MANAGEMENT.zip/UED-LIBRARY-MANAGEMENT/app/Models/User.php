<?php
/**
 * Model User - làm việc với bảng `users`.
 */
class User
{
    public const ROLES = ['admin', 'librarian', 'teacher', 'student'];

    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function findByEmail(string $email): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => $email]);
        return $stmt->fetch() ?: null;
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch() ?: null;
    }

    /** Kiểm tra email đã tồn tại chưa (bỏ qua chính tài khoản $exceptId khi cập nhật). */
    public function emailExists(string $email, ?int $exceptId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM users WHERE email = :email';
        $params = ['email' => $email];
        if ($exceptId !== null) {
            $sql .= ' AND id <> :id';
            $params['id'] = $exceptId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn() > 0;
    }

    /** Tạo tài khoản mới, trả về id vừa tạo. Mật khẩu được băm tại đây. */
    public function create(array $data): int
    {
        $stmt = $this->db->prepare(
            'INSERT INTO users (full_name, email, password, role)
             VALUES (:full_name, :email, :password, :role)'
        );
        $stmt->execute([
            'full_name' => $data['full_name'],
            'email'     => $data['email'],
            'password'  => password_hash($data['password'], PASSWORD_DEFAULT),
            'role'      => $data['role'] ?? 'student',
        ]);
        return (int) $this->db->lastInsertId();
    }

    /** Cập nhật họ tên và email. */
    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE users SET full_name = :full_name, email = :email WHERE id = :id'
        );
        return $stmt->execute([
            'full_name' => $data['full_name'],
            'email'     => $data['email'],
            'id'        => $id,
        ]);
    }

    public function updatePassword(int $id, string $newPassword): bool
    {
        $stmt = $this->db->prepare('UPDATE users SET password = :password WHERE id = :id');
        return $stmt->execute([
            'password' => password_hash($newPassword, PASSWORD_DEFAULT),
            'id'       => $id,
        ]);
    }

    /** Danh sách tất cả tài khoản, có thể lọc theo từ khóa (tên hoặc email). */
    public function all(string $keyword = ''): array
    {
        if ($keyword !== '') {
            $stmt = $this->db->prepare(
                'SELECT id, full_name, email, role, status, created_at FROM users
                 WHERE full_name LIKE :kw OR email LIKE :kw
                 ORDER BY id DESC'
            );
            $stmt->execute(['kw' => '%' . $keyword . '%']);
            return $stmt->fetchAll();
        }
        return $this->db->query(
            'SELECT id, full_name, email, role, status, created_at FROM users ORDER BY id DESC'
        )->fetchAll();
    }

    /** Phân quyền: đổi vai trò của tài khoản. */
    public function updateRole(int $id, string $role): bool
    {
        if (!in_array($role, self::ROLES, true)) {
            return false;
        }
        $stmt = $this->db->prepare('UPDATE users SET role = :role WHERE id = :id');
        return $stmt->execute(['role' => $role, 'id' => $id]);
    }

    /** Khóa hoặc mở khóa tài khoản (active / locked). */
    public function updateStatus(int $id, string $status): bool
    {
        if (!in_array($status, ['active', 'locked'], true)) {
            return false;
        }
        $stmt = $this->db->prepare('UPDATE users SET status = :status WHERE id = :id');
        return $stmt->execute(['status' => $status, 'id' => $id]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare('DELETE FROM users WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }
}
