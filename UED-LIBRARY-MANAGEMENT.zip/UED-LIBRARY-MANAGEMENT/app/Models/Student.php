<?php
/**
 * Model Student - thông tin riêng của sinh viên, bảng `students`.
 */
class Student
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function findByUserId(int $userId): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM students WHERE user_id = :user_id LIMIT 1');
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetch() ?: null;
    }

    public function codeExists(string $code, ?int $exceptUserId = null): bool
    {
        $sql = 'SELECT COUNT(*) FROM students WHERE student_code = :code';
        $params = ['code' => $code];
        if ($exceptUserId !== null) {
            $sql .= ' AND user_id <> :user_id';
            $params['user_id'] = $exceptUserId;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn() > 0;
    }

    public function create(int $userId, array $data): bool
    {
        $stmt = $this->db->prepare(
            'INSERT INTO students (user_id, student_code, class_name, phone)
             VALUES (:user_id, :student_code, :class_name, :phone)'
        );
        return $stmt->execute([
            'user_id'      => $userId,
            'student_code' => $data['student_code'],
            'class_name'   => $data['class_name'] ?? null,
            'phone'        => $data['phone'] ?? null,
        ]);
    }

    public function updateByUserId(int $userId, array $data): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE students SET class_name = :class_name, phone = :phone WHERE user_id = :user_id'
        );
        return $stmt->execute([
            'class_name' => $data['class_name'] ?? null,
            'phone'      => $data['phone'] ?? null,
            'user_id'    => $userId,
        ]);
    }
}
