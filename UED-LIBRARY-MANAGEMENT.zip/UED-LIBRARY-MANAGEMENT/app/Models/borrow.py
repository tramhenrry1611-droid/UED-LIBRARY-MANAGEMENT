
from config.database import get_connection


class Borrow:

    # 1. LAY DANH SACH SACH CO THE MUON
    @staticmethod
    def get_available_books():
        connection = get_connection()

        if connection is None:
            return []

        try:
            cursor = connection.cursor(dictionary=True)

            sql = """
                SELECT book_id, title, author, quantity_available
                FROM books
                WHERE quantity_available > 0
            """

            cursor.execute(sql)
            books = cursor.fetchall()

            return books

        except Exception as e:
            print("Loi lay danh sach sach:", e)
            return []

        finally:
            cursor.close()
            connection.close()

    # 2. DANG KY MUON SACH
    @staticmethod
    def create_borrow(student_id, book_id, borrow_date, due_date, note=None):
        connection = get_connection()

        if connection is None:
            return False, "Khong ket noi duoc database!"

        try:
            cursor = connection.cursor(dictionary=True)

            # Kiem tra sinh vien
            cursor.execute(
                "SELECT student_id FROM students WHERE student_id = %s",
                (student_id,)
            )

            student = cursor.fetchone()

            if not student:
                return False, "Sinh vien khong ton tai!"

            # Kiem tra sach
            cursor.execute(
                """
                SELECT book_id, title, quantity_available
                FROM books
                WHERE book_id = %s
                """,
                (book_id,)
            )

            book = cursor.fetchone()

            if not book:
                return False, "Sach khong ton tai!"

            if book["quantity_available"] <= 0:
                return False, "Sach hien khong con de muon!"

            # Tao phieu muon
            sql = """
                INSERT INTO borrows
                (student_id, book_id, borrow_date, due_date, status, note)
                VALUES (%s, %s, %s, %s, 'pending', %s)
            """

            cursor.execute(
                sql,
                (student_id, book_id, borrow_date, due_date, note)
            )

            connection.commit()

            return True, "Dang ky muon sach thanh cong!"

        except Exception as e:
            connection.rollback()
            print("Loi dang ky muon sach:", e)
            return False, "Khong the dang ky muon sach!"

        finally:
            cursor.close()
            connection.close()

    # 3. LAY DANH SACH PHIEU MUON CUA SINH VIEN
    @staticmethod
    def get_student_borrows(student_id):
        connection = get_connection()

        if connection is None:
            return []

        try:
            cursor = connection.cursor(dictionary=True)

            sql = """
                SELECT
                    b.borrow_id,
                    s.student_code,
                    s.full_name,
                    bk.title,
                    bk.author,
                    b.borrow_date,
                    b.due_date,
                    b.status,
                    b.note
                FROM borrows b
                JOIN students s
                    ON b.student_id = s.student_id
                JOIN books bk
                    ON b.book_id = bk.book_id
                WHERE b.student_id = %s
                ORDER BY b.created_at DESC
            """

            cursor.execute(sql, (student_id,))
            return cursor.fetchall()

        except Exception as e:
            print("Loi lay phieu muon:", e)
            return []

        finally:
            cursor.close()
            connection.close()

    # 4. LAY TAT CA PHIEU MUON
    @staticmethod
    def get_all_borrows():
        connection = get_connection()

        if connection is None:
            return []

        try:
            cursor = connection.cursor(dictionary=True)

            sql = """
                SELECT
                    b.borrow_id,
                    s.student_code,
                    s.full_name,
                    bk.title,
                    b.borrow_date,
                    b.due_date,
                    b.status,
                    b.note
                FROM borrows b
                JOIN students s
                    ON b.student_id = s.student_id
                JOIN books bk
                    ON b.book_id = bk.book_id
                ORDER BY b.created_at DESC
            """

            cursor.execute(sql)
            return cursor.fetchall()

        except Exception as e:
            print("Loi lay danh sach phieu:", e)
            return []

        finally:
            cursor.close()
            connection.close()

    # 5. DUYET PHIEU MUON
    @staticmethod
    def approve_borrow(borrow_id, librarian_id):
        connection = get_connection()

        if connection is None:
            return False, "Khong ket noi duoc database!"

        try:
            cursor = connection.cursor(dictionary=True)

            # Kiem tra phieu muon
            cursor.execute(
                """
                SELECT borrow_id, book_id, status
                FROM borrows
                WHERE borrow_id = %s
                FOR UPDATE
                """,
                (borrow_id,)
            )

            borrow = cursor.fetchone()

            if not borrow:
                return False, "Khong tim thay phieu muon!"

            if borrow["status"] != "pending":
                return False, "Phieu muon khong o trang thai cho duyet!"

            # Kiem tra va tru so luong sach
            cursor.execute(
                """
                UPDATE books
                SET quantity_available = quantity_available - 1
                WHERE book_id = %s
                AND quantity_available > 0
                """,
                (borrow["book_id"],)
            )

            if cursor.rowcount == 0:
                return False, "Sach da het!"

            # Cap nhat trang thai phieu
            cursor.execute(
                """
                UPDATE borrows
                SET status = 'approved',
                    approved_by = %s,
                    approved_at = NOW()
                WHERE borrow_id = %s
                """,
                (librarian_id, borrow_id)
            )

            connection.commit()

            return True, "Duyet phieu muon thanh cong!"

        except Exception as e:
            connection.rollback()
            print("Loi duyet phieu:", e)
            return False, "Khong the duyet phieu muon!"

        finally:
            cursor.close()
            connection.close()

    # 6. TU CHOI PHIEU MUON
    @staticmethod
    def reject_borrow(borrow_id, librarian_id):
        connection = get_connection()

        if connection is None:
            return False, "Khong ket noi duoc database!"

        try:
            cursor = connection.cursor()

            sql = """
                UPDATE borrows
                SET status = 'rejected',
                    approved_by = %s,
                    approved_at = NOW()
                WHERE borrow_id = %s
                AND status = 'pending'
            """

            cursor.execute(sql, (librarian_id, borrow_id))

            if cursor.rowcount == 0:
                return False, "Khong tim thay phieu cho duyet!"

            connection.commit()

            return True, "Tu choi phieu muon thanh cong!"

        except Exception as e:
            connection.rollback()
            print("Loi tu choi phieu:", e)
            return False, "Khong the tu choi phieu!"

        finally:
            cursor.close()
            connection.close()
