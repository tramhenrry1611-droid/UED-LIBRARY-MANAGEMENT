<?php
$currentUser = $_SESSION['user'] ?? null;
$flash = pullFlash();
$roleNames = [
    'admin'     => 'Quản trị viên',
    'librarian' => 'Thủ thư',
    'teacher'   => 'Giảng viên',
    'student'   => 'Sinh viên',
];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'Thư viện UED') ?> - Thư viện UED</title>
    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
</head>
<body>
<header class="topbar">
    <a class="brand" href="<?= e(url('/')) ?>">Thư viện UED</a>
    <nav>
        <?php if ($currentUser): ?>
            <?php if ($currentUser['role'] === 'admin'): ?>
                <a href="<?= e(url('/admin/users')) ?>">Quản lý tài khoản</a>
            <?php elseif ($currentUser['role'] === 'student'): ?>
                <a href="<?= e(url('/student/profile')) ?>">Thông tin của tôi</a>
            <?php elseif ($currentUser['role'] === 'teacher'): ?>
                <a href="<?= e(url('/teacher/profile')) ?>">Thông tin của tôi</a>
            <?php endif; ?>
            <span class="user-chip">
                <?= e($currentUser['full_name']) ?> (<?= e($roleNames[$currentUser['role']] ?? $currentUser['role']) ?>)
            </span>
            <a href="<?= e(url('/logout')) ?>">Đăng xuất</a>
        <?php else: ?>
            <a href="<?= e(url('/login')) ?>">Đăng nhập</a>
            <a href="<?= e(url('/register')) ?>">Đăng ký</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
    <?php endif; ?>
