<div class="card center">
    <h1>404</h1>
    <p>Không tìm thấy trang bạn yêu cầu.</p>
    <a class="btn" href="<?= e(url('/')) ?>">Về trang chủ</a>
</div>
