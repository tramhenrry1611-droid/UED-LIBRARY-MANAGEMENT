</main>
<footer class="footer">
    <p>&copy; <?= date('Y') ?> Hệ thống quản lý thư viện UED</p>
</footer>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
