<div class="card center">
    <h1>403</h1>
    <p>Bạn không có quyền truy cập trang này.</p>
    <a class="btn" href="<?= e(url('/')) ?>">Về trang chủ</a>
</div>
