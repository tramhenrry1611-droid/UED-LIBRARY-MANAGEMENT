<div class="card narrow">
    <h1>Thông tin sinh viên</h1>
    <form method="post" action="<?= e(url('/student/profile')) ?>">
        <?= csrfField() ?>

        <label>Mã sinh viên</label>
        <input type="text" value="<?= e($student['student_code'] ?? '') ?>" disabled>

        <label for="full_name">Họ và tên</label>
        <input type="text" id="full_name" name="full_name" value="<?= e($user['full_name']) ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($user['email']) ?>" required>

        <label for="class_name">Lớp</label>
        <input type="text" id="class_name" name="class_name" value="<?= e($student['class_name'] ?? '') ?>">

        <label for="phone">Số điện thoại</label>
        <input type="text" id="phone" name="phone" value="<?= e($student['phone'] ?? '') ?>">

        <h2>Đổi mật khẩu</h2>
        <p class="muted">Để trống nếu không muốn đổi.</p>

        <label for="current_password">Mật khẩu hiện tại</label>
        <input type="password" id="current_password" name="current_password" autocomplete="current-password">

        <label for="new_password">Mật khẩu mới</label>
        <input type="password" id="new_password" name="new_password" minlength="6" autocomplete="new-password">

        <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
    </form>
</div>
