<?php $oldRole = old('role', 'student'); ?>
<div class="card narrow">
    <h1>Đăng ký tài khoản</h1>
    <form method="post" action="<?= e(url('/register')) ?>">
        <?= csrfField() ?>

        <label for="role">Bạn là</label>
        <select id="role" name="role">
            <option value="student" <?= $oldRole === 'student' ? 'selected' : '' ?>>Sinh viên</option>
            <option value="teacher" <?= $oldRole === 'teacher' ? 'selected' : '' ?>>Giảng viên</option>
        </select>

        <label for="full_name">Họ và tên</label>
        <input type="text" id="full_name" name="full_name" value="<?= e(old('full_name')) ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e(old('email')) ?>" required>

        <label for="code" id="code-label">Mã sinh viên</label>
        <input type="text" id="code" name="code" value="<?= e(old('code')) ?>" required>

        <label for="extra" id="extra-label">Lớp</label>
        <input type="text" id="extra" name="extra" value="<?= e(old('extra')) ?>">

        <label for="phone">Số điện thoại</label>
        <input type="text" id="phone" name="phone" value="<?= e(old('phone')) ?>">

        <label for="password">Mật khẩu (tối thiểu 6 ký tự)</label>
        <input type="password" id="password" name="password" required minlength="6">

        <label for="password_confirm">Nhập lại mật khẩu</label>
        <input type="password" id="password_confirm" name="password_confirm" required minlength="6">

        <button type="submit" class="btn btn-primary">Đăng ký</button>
    </form>
    <p class="muted">Đã có tài khoản? <a href="<?= e(url('/login')) ?>">Đăng nhập</a></p>
</div>
