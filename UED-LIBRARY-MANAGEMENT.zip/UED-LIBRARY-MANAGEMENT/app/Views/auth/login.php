<div class="card narrow">
    <h1>Đăng nhập</h1>
    <form method="post" action="<?= e(url('/login')) ?>">
        <?= csrfField() ?>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e(old('email')) ?>" required autofocus>

        <label for="password">Mật khẩu</label>
        <input type="password" id="password" name="password" required>

        <button type="submit" class="btn btn-primary">Đăng nhập</button>
    </form>
    <p class="muted">Chưa có tài khoản? <a href="<?= e(url('/register')) ?>">Đăng ký</a></p>
</div>
