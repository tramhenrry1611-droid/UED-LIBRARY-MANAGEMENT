<?php
$roleNames = [
    'admin'     => 'Quản trị viên',
    'librarian' => 'Thủ thư',
    'teacher'   => 'Giảng viên',
    'student'   => 'Sinh viên',
];
?>
<div class="card narrow">
    <h1>Sửa tài khoản #<?= e($user['id']) ?></h1>
    <form method="post" action="<?= e(url('/admin/users/' . $user['id'] . '/update')) ?>">
        <?= csrfField() ?>

        <label for="full_name">Họ và tên</label>
        <input type="text" id="full_name" name="full_name" value="<?= e($user['full_name']) ?>" required>

        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($user['email']) ?>" required>

        <label for="role">Quyền</label>
        <select id="role" name="role">
            <?php foreach ($roles as $r): ?>
                <option value="<?= e($r) ?>" <?= $user['role'] === $r ? 'selected' : '' ?>><?= e($roleNames[$r]) ?></option>
            <?php endforeach; ?>
        </select>

        <label for="status">Trạng thái</label>
        <select id="status" name="status">
            <option value="active" <?= $user['status'] === 'active' ? 'selected' : '' ?>>Hoạt động</option>
            <option value="locked" <?= $user['status'] === 'locked' ? 'selected' : '' ?>>Khóa</option>
        </select>

        <label for="password">Mật khẩu mới (để trống nếu không đổi)</label>
        <input type="password" id="password" name="password" minlength="6" autocomplete="new-password">

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
            <a class="btn" href="<?= e(url('/admin/users')) ?>">Quay lại</a>
        </div>
    </form>
</div>
