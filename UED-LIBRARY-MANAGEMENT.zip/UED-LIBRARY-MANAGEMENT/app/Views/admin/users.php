<?php
$roleNames = [
    'admin'     => 'Quản trị viên',
    'librarian' => 'Thủ thư',
    'teacher'   => 'Giảng viên',
    'student'   => 'Sinh viên',
];
?>
<div class="card">
    <div class="card-head">
        <h1>Quản lý tài khoản</h1>
        <form method="get" action="<?= e(url('/admin/users')) ?>" class="inline-form">
            <input type="text" name="q" value="<?= e($keyword) ?>" placeholder="Tìm theo tên hoặc email">
            <button type="submit" class="btn">Tìm</button>
        </form>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>Quyền</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($users)): ?>
                <tr><td colspan="6" class="center muted">Không có tài khoản nào.</td></tr>
            <?php endif; ?>
            <?php foreach ($users as $u): ?>
                <?php $isMe = (int) $u['id'] === $_SESSION['user']['id']; ?>
                <tr>
                    <td><?= e($u['id']) ?></td>
                    <td><?= e($u['full_name']) ?><?= $isMe ? ' <span class="badge">Bạn</span>' : '' ?></td>
                    <td><?= e($u['email']) ?></td>
                    <td>
                        <form method="post" action="<?= e(url('/admin/users/' . $u['id'] . '/role')) ?>" class="inline-form">
                            <?= csrfField() ?>
                            <select name="role" <?= $isMe ? 'disabled' : '' ?>>
                                <?php foreach ($roles as $r): ?>
                                    <option value="<?= e($r) ?>" <?= $u['role'] === $r ? 'selected' : '' ?>>
                                        <?= e($roleNames[$r]) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (!$isMe): ?>
                                <button type="submit" class="btn btn-small">Lưu</button>
                            <?php endif; ?>
                        </form>
                    </td>
                    <td>
                        <span class="badge <?= $u['status'] === 'active' ? 'badge-ok' : 'badge-lock' ?>">
                            <?= $u['status'] === 'active' ? 'Hoạt động' : 'Đã khóa' ?>
                        </span>
                    </td>
                    <td class="actions">
                        <a class="btn btn-small" href="<?= e(url('/admin/users/' . $u['id'] . '/edit')) ?>">Sửa</a>
                        <?php if (!$isMe): ?>
                            <form method="post" action="<?= e(url('/admin/users/' . $u['id'] . '/status')) ?>" class="inline-form">
                                <?= csrfField() ?>
                                <input type="hidden" name="status" value="<?= $u['status'] === 'active' ? 'locked' : 'active' ?>">
                                <button type="submit" class="btn btn-small">
                                    <?= $u['status'] === 'active' ? 'Khóa' : 'Mở khóa' ?>
                                </button>
                            </form>
                            <form method="post" action="<?= e(url('/admin/users/' . $u['id'] . '/delete')) ?>" class="inline-form"
                                  data-confirm="Xóa tài khoản <?= e($u['full_name']) ?>? Hành động này không thể hoàn tác.">
                                <?= csrfField() ?>
                                <button type="submit" class="btn btn-small btn-danger">Xóa</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
