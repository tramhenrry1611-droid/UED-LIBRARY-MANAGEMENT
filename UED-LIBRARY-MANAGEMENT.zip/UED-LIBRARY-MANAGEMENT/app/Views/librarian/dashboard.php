<div class="card center">
    <h1>Xin chào, <?= e($_SESSION['user']['full_name']) ?></h1>
    <p class="muted">Các chức năng mượn, trả sách do thành viên khác trong nhóm phụ trách sẽ hiển thị tại đây.</p>
</div>
