<?php
/**
 * StudentController - sinh viên xem và cập nhật thông tin tài khoản của mình.
 */
class StudentController
{
    private User $userModel;
    private Student $studentModel;

    public function __construct()
    {
        $this->userModel    = new User();
        $this->studentModel = new Student();
    }

    public function profile(): void
    {
        AuthController::requireRole(['student']);

        $userId = $_SESSION['user']['id'];

        view('student/profile', [
            'title'   => 'Thông tin sinh viên',
            'user'    => $this->userModel->findById($userId),
            'student' => $this->studentModel->findByUserId($userId),
        ]);
    }

    public function updateProfile(): void
    {
        AuthController::requireRole(['student']);
        verifyCsrf();

        $userId   = $_SESSION['user']['id'];
        $user     = $this->userModel->findById($userId);
        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $current  = $_POST['current_password'] ?? '';
        $new      = $_POST['new_password'] ?? '';

        if ($fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Họ tên hoặc email không hợp lệ.');
            redirect('/student/profile');
        }
        if ($this->userModel->emailExists($email, $userId)) {
            flash('error', 'Email này đã được dùng bởi tài khoản khác.');
            redirect('/student/profile');
        }
        if ($new !== '') {
            if (!password_verify($current, $user['password'])) {
                flash('error', 'Mật khẩu hiện tại không đúng.');
                redirect('/student/profile');
            }
            if (strlen($new) < 6) {
                flash('error', 'Mật khẩu mới phải có ít nhất 6 ký tự.');
                redirect('/student/profile');
            }
        }

        $this->userModel->update($userId, ['full_name' => $fullName, 'email' => $email]);
        $this->studentModel->updateByUserId($userId, [
            'class_name' => trim($_POST['class_name'] ?? ''),
            'phone'      => trim($_POST['phone'] ?? ''),
        ]);
        if ($new !== '') {
            $this->userModel->updatePassword($userId, $new);
        }

        $_SESSION['user']['full_name'] = $fullName;
        $_SESSION['user']['email']     = $email;

        flash('success', 'Đã cập nhật thông tin.');
        redirect('/student/profile');
    }
}
