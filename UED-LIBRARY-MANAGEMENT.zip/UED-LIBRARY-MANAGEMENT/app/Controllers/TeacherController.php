<?php
/**
 * TeacherController - giảng viên xem và cập nhật thông tin tài khoản của mình.
 */
class TeacherController
{
    private User $userModel;
    private Teacher $teacherModel;

    public function __construct()
    {
        $this->userModel    = new User();
        $this->teacherModel = new Teacher();
    }

    public function profile(): void
    {
        AuthController::requireRole(['teacher']);

        $userId = $_SESSION['user']['id'];

        view('teacher/profile', [
            'title'   => 'Thông tin giảng viên',
            'user'    => $this->userModel->findById($userId),
            'teacher' => $this->teacherModel->findByUserId($userId),
        ]);
    }

    public function updateProfile(): void
    {
        AuthController::requireRole(['teacher']);
        verifyCsrf();

        $userId   = $_SESSION['user']['id'];
        $user     = $this->userModel->findById($userId);
        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $current  = $_POST['current_password'] ?? '';
        $new      = $_POST['new_password'] ?? '';

        if ($fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Họ tên hoặc email không hợp lệ.');
            redirect('/teacher/profile');
        }
        if ($this->userModel->emailExists($email, $userId)) {
            flash('error', 'Email này đã được dùng bởi tài khoản khác.');
            redirect('/teacher/profile');
        }
        if ($new !== '') {
            if (!password_verify($current, $user['password'])) {
                flash('error', 'Mật khẩu hiện tại không đúng.');
                redirect('/teacher/profile');
            }
            if (strlen($new) < 6) {
                flash('error', 'Mật khẩu mới phải có ít nhất 6 ký tự.');
                redirect('/teacher/profile');
            }
        }

        $this->userModel->update($userId, ['full_name' => $fullName, 'email' => $email]);
        $this->teacherModel->updateByUserId($userId, [
            'department' => trim($_POST['department'] ?? ''),
            'phone'      => trim($_POST['phone'] ?? ''),
        ]);
        if ($new !== '') {
            $this->userModel->updatePassword($userId, $new);
        }

        $_SESSION['user']['full_name'] = $fullName;
        $_SESSION['user']['email']     = $email;

        flash('success', 'Đã cập nhật thông tin.');
        redirect('/teacher/profile');
    }
}
