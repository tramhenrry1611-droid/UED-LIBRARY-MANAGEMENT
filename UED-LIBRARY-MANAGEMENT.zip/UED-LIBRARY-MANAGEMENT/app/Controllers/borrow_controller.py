
from flask import Blueprint, render_template, request, redirect, url_for, flash
from app.Models.borrow import Borrow

borrow_bp = Blueprint("borrow", __name__)


# 1. Trang dang ky muon sach
@borrow_bp.route("/student/borrow", methods=["GET", "POST"])
def borrow_book():

    if request.method == "POST":
        student_id = request.form.get("student_id")
        book_id = request.form.get("book_id")
        borrow_date = request.form.get("borrow_date")
        due_date = request.form.get("due_date")
        note = request.form.get("note")

        if not student_id or not book_id or not borrow_date or not due_date:
            flash("Vui long nhap day du thong tin!", "error")
            return redirect(url_for("borrow.borrow_book"))

        success, message = Borrow.create_borrow(
            student_id,
            book_id,
            borrow_date,
            due_date,
            note
        )

        flash(message, "success" if success else "error")

        return redirect(url_for("borrow.borrow_book"))

    books = Borrow.get_available_books()

    return render_template(
        "student/borrow.html",
        books=books
    )


# 2. Danh sach phieu muon cua sinh vien
@borrow_bp.route("/student/my-borrows/<int:student_id>")
def my_borrows(student_id):

    borrows = Borrow.get_student_borrows(student_id)

    return render_template(
        "student/my_borrows.html",
        borrows=borrows
    )


# 3. Danh sach phieu muon cho thu thu
@borrow_bp.route("/librarian/borrows")
def borrow_list():

    borrows = Borrow.get_all_borrows()

    return render_template(
        "librarian/borrow_list.html",
        borrows=borrows
    )


# 4. Duyet phieu muon
@borrow_bp.route("/librarian/approve/<int:borrow_id>", methods=["POST"])
def approve_borrow(borrow_id):

    librarian_id = request.form.get("librarian_id")

    if not librarian_id:
        flash("Thieu thong tin thu thu!", "error")
        return redirect(url_for("borrow.borrow_list"))

    success, message = Borrow.approve_borrow(
        borrow_id,
        librarian_id
    )

    flash(message, "success" if success else "error")

    return redirect(url_for("borrow.borrow_list"))


# 5. Tu choi phieu muon
@borrow_bp.route("/librarian/reject/<int:borrow_id>", methods=["POST"])
def reject_borrow(borrow_id):

    librarian_id = request.form.get("librarian_id")

    if not librarian_id:
        flash("Thieu thong tin thu thu!", "error")
        return redirect(url_for("borrow.borrow_list"))

    success, message = Borrow.reject_borrow(
        borrow_id,
        librarian_id
    )

    flash(message, "success" if success else "error")

    return redirect(url_for("borrow.borrow_list"))
