<?php
/**
 * AdminController - quản lý tài khoản và phân quyền (chỉ vai trò admin).
 */
class AdminController
{
    private User $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    /** Danh sách tài khoản, có tìm kiếm theo tên hoặc email. */
    public function users(): void
    {
        AuthController::requireRole(['admin']);

        $keyword = trim($_GET['q'] ?? '');

        view('admin/users', [
            'title'   => 'Quản lý tài khoản',
            'users'   => $this->userModel->all($keyword),
            'keyword' => $keyword,
            'roles'   => User::ROLES,
        ]);
    }

    public function editUser($id): void
    {
        AuthController::requireRole(['admin']);

        $user = $this->userModel->findById((int) $id);
        if ($user === null) {
            flash('error', 'Không tìm thấy tài khoản.');
            redirect('/admin/users');
        }

        view('admin/edit_user', [
            'title' => 'Sửa tài khoản',
            'user'  => $user,
            'roles' => User::ROLES,
        ]);
    }

    /** Cập nhật họ tên, email, vai trò, trạng thái và (tùy chọn) mật khẩu mới. */
    public function updateUser($id): void
    {
        AuthController::requireRole(['admin']);
        verifyCsrf();

        $id   = (int) $id;
        $user = $this->userModel->findById($id);
        if ($user === null) {
            flash('error', 'Không tìm thấy tài khoản.');
            redirect('/admin/users');
        }

        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $role     = $_POST['role'] ?? $user['role'];
        $status   = $_POST['status'] ?? $user['status'];
        $password = $_POST['password'] ?? '';

        $back = '/admin/users/' . $id . '/edit';

        if ($fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Họ tên hoặc email không hợp lệ.');
            redirect($back);
        }
        if ($this->userModel->emailExists($email, $id)) {
            flash('error', 'Email này đã thuộc về tài khoản khác.');
            redirect($back);
        }
        if ($password !== '' && strlen($password) < 6) {
            flash('error', 'Mật khẩu mới phải có ít nhất 6 ký tự.');
            redirect($back);
        }
        if ($id === $_SESSION['user']['id'] && ($role !== 'admin' || $status !== 'active')) {
            flash('error', 'Bạn không thể tự hạ quyền hoặc khóa chính mình.');
            redirect($back);
        }

        $this->userModel->update($id, ['full_name' => $fullName, 'email' => $email]);
        $this->userModel->updateRole($id, $role);
        $this->userModel->updateStatus($id, $status);
        if ($password !== '') {
            $this->userModel->updatePassword($id, $password);
        }

        if ($id === $_SESSION['user']['id']) {
            $_SESSION['user']['full_name'] = $fullName;
            $_SESSION['user']['email']     = $email;
        }

        flash('success', 'Đã cập nhật tài khoản.');
        redirect('/admin/users');
    }

    /** Phân quyền nhanh ngay trên danh sách. */
    public function updateRole($id): void
    {
        AuthController::requireRole(['admin']);
        verifyCsrf();

        $id   = (int) $id;
        $role = $_POST['role'] ?? '';

        if ($id === $_SESSION['user']['id']) {
            flash('error', 'Bạn không thể tự đổi quyền của chính mình.');
            redirect('/admin/users');
        }
        if (!$this->userModel->updateRole($id, $role)) {
            flash('error', 'Vai trò không hợp lệ.');
            redirect('/admin/users');
        }

        flash('success', 'Đã cập nhật quyền.');
        redirect('/admin/users');
    }

    /** Khóa hoặc mở khóa tài khoản. */
    public function updateStatus($id): void
    {
        AuthController::requireRole(['admin']);
        verifyCsrf();

        $id     = (int) $id;
        $status = $_POST['status'] ?? '';

        if ($id === $_SESSION['user']['id']) {
            flash('error', 'Bạn không thể khóa chính mình.');
            redirect('/admin/users');
        }
        if (!$this->userModel->updateStatus($id, $status)) {
            flash('error', 'Trạng thái không hợp lệ.');
            redirect('/admin/users');
        }

        flash('success', $status === 'locked' ? 'Đã khóa tài khoản.' : 'Đã mở khóa tài khoản.');
        redirect('/admin/users');
    }

    public function deleteUser($id): void
    {
        AuthController::requireRole(['admin']);
        verifyCsrf();

        $id = (int) $id;
        if ($id === $_SESSION['user']['id']) {
            flash('error', 'Bạn không thể xóa chính mình.');
            redirect('/admin/users');
        }

        $this->userModel->delete($id);
        flash('success', 'Đã xóa tài khoản.');
        redirect('/admin/users');
    }
}
