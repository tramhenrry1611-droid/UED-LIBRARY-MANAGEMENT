<?php
/**
 * AuthController - đăng nhập, đăng ký, đăng xuất, kiểm tra đăng nhập và phân quyền.
 */
class AuthController
{
    private User $userModel;
    private Student $studentModel;
    private Teacher $teacherModel;

    public function __construct()
    {
        $this->userModel    = new User();
        $this->studentModel = new Student();
        $this->teacherModel = new Teacher();
    }

    /* ---------------- Trang chủ: chuyển hướng theo vai trò ---------------- */

    public function home(): void
    {
        self::requireLogin();

        switch ($_SESSION['user']['role']) {
            case 'admin':
                redirect('/admin/users');
            case 'student':
                redirect('/student/profile');
            case 'teacher':
                redirect('/teacher/profile');
            default: // librarian: các chức năng mượn/trả do thành viên khác phụ trách
                view('librarian/dashboard', ['title' => 'Thủ thư']);
        }
    }

    /* ---------------- Đăng nhập ---------------- */

    public function showLogin(): void
    {
        if (isset($_SESSION['user'])) {
            redirect('/');
        }
        view('auth/login', ['title' => 'Đăng nhập']);
    }

    public function login(): void
    {
        verifyCsrf();

        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        $_SESSION['old'] = ['email' => $email];

        if ($email === '' || $password === '') {
            flash('error', 'Vui lòng nhập email và mật khẩu.');
            redirect('/login');
        }

        $user = $this->userModel->findByEmail($email);

        if ($user === null || !password_verify($password, $user['password'])) {
            flash('error', 'Email hoặc mật khẩu không đúng.');
            redirect('/login');
        }

        if ($user['status'] !== 'active') {
            flash('error', 'Tài khoản đã bị khóa. Vui lòng liên hệ quản trị viên.');
            redirect('/login');
        }

        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'        => (int) $user['id'],
            'full_name' => $user['full_name'],
            'email'     => $user['email'],
            'role'      => $user['role'],
        ];
        unset($_SESSION['old']);

        redirect('/');
    }

    /* ---------------- Đăng ký ---------------- */

    public function showRegister(): void
    {
        if (isset($_SESSION['user'])) {
            redirect('/');
        }
        view('auth/register', ['title' => 'Đăng ký']);
    }

    public function register(): void
    {
        verifyCsrf();

        $data = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'email'     => trim($_POST['email'] ?? ''),
            'role'      => $_POST['role'] ?? 'student',
            'code'      => trim($_POST['code'] ?? ''),
            'extra'     => trim($_POST['extra'] ?? ''),   // lớp (sinh viên) hoặc khoa (giảng viên)
            'phone'     => trim($_POST['phone'] ?? ''),
        ];
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['password_confirm'] ?? '';

        $_SESSION['old'] = $data;

        $error = $this->validateRegister($data, $password, $confirm);
        if ($error !== null) {
            flash('error', $error);
            redirect('/register');
        }

        $db = Database::getConnection();
        try {
            $db->beginTransaction();

            $userId = $this->userModel->create([
                'full_name' => $data['full_name'],
                'email'     => $data['email'],
                'password'  => $password,
                'role'      => $data['role'],
            ]);

            if ($data['role'] === 'student') {
                $this->studentModel->create($userId, [
                    'student_code' => $data['code'],
                    'class_name'   => $data['extra'],
                    'phone'        => $data['phone'],
                ]);
            } else {
                $this->teacherModel->create($userId, [
                    'teacher_code' => $data['code'],
                    'department'   => $data['extra'],
                    'phone'        => $data['phone'],
                ]);
            }

            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            flash('error', 'Đăng ký thất bại, vui lòng thử lại.');
            redirect('/register');
        }

        unset($_SESSION['old']);
        flash('success', 'Đăng ký thành công. Bạn có thể đăng nhập.');
        redirect('/login');
    }

    /** Trả về thông báo lỗi đầu tiên, hoặc null nếu dữ liệu hợp lệ. */
    private function validateRegister(array $data, string $password, string $confirm): ?string
    {
        if ($data['full_name'] === '' || $data['email'] === '' || $data['code'] === '') {
            return 'Vui lòng nhập đầy đủ họ tên, email và mã số.';
        }
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            return 'Email không hợp lệ.';
        }
        if (!in_array($data['role'], ['student', 'teacher'], true)) {
            return 'Vai trò không hợp lệ.';
        }
        if (strlen($password) < 6) {
            return 'Mật khẩu phải có ít nhất 6 ký tự.';
        }
        if ($password !== $confirm) {
            return 'Mật khẩu nhập lại không khớp.';
        }
        if ($this->userModel->emailExists($data['email'])) {
            return 'Email này đã được đăng ký.';
        }

        $codeExists = $data['role'] === 'student'
            ? $this->studentModel->codeExists($data['code'])
            : $this->teacherModel->codeExists($data['code']);
        if ($codeExists) {
            return 'Mã số này đã tồn tại.';
        }

        return null;
    }

    /* ---------------- Đăng xuất ---------------- */

    public function logout(): void
    {
        $_SESSION = [];
        session_destroy();
        session_start();
        flash('success', 'Bạn đã đăng xuất.');
        redirect('/login');
    }

    /* ---------------- Phân quyền (dùng ở các Controller khác) ---------------- */

    /** Bắt buộc đã đăng nhập, nếu chưa thì chuyển về trang đăng nhập. */
    public static function requireLogin(): void
    {
        if (!isset($_SESSION['user'])) {
            flash('error', 'Vui lòng đăng nhập để tiếp tục.');
            redirect('/login');
        }
    }

    /** Bắt buộc đã đăng nhập và có vai trò nằm trong danh sách $roles. */
    public static function requireRole(array $roles): void
    {
        self::requireLogin();

        if (!in_array($_SESSION['user']['role'], $roles, true)) {
            http_response_code(403);
            view('layouts/403', ['title' => 'Không có quyền truy cập']);
            exit;
        }
    }
}
