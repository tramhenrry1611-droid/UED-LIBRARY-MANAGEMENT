from flask import Flask
from routes.web import register_routes

app = Flask(__name__, template_folder="app/Views")
app.secret_key = "ued-library-secret-key"

register_routes(app)

if __name__ == "__main__":
    app.run(debug=True)