<?php
/**
 * Cấu hình kết nối CSDL (MySQL qua PDO).
 * Mặc định theo XAMPP: user = root, mật khẩu rỗng.
 * Nếu máy bạn khác, chỉ cần sửa 4 hằng số bên dưới.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'ued_library');
define('DB_USER', 'root');
define('DB_PASS', '');

class Database
{
    private static ?PDO $connection = null;

    /** Trả về cùng một kết nối PDO cho toàn bộ ứng dụng. */
    public static function getConnection(): PDO
    {
        if (self::$connection === null) {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            try {
                self::$connection = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                http_response_code(500);
                exit('Không kết nối được CSDL. Hãy kiểm tra MySQL đã chạy và đã import database.sql chưa.');
            }
        }
        return self::$connection;
    }
}
