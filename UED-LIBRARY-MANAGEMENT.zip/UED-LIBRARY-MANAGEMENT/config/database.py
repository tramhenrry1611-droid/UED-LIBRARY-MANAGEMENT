
import mysql.connector
from mysql.connector import Error

def get_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="130806",
            database="ued_library",
            port=3306
        )

        if connection.is_connected():
            print("Ket noi MySQL thanh cong!")
            return connection

    except Error as e:
        print("Loi ket noi MySQL:", e)

    return None