// Hỏi xác nhận trước khi gửi form có thuộc tính data-confirm (ví dụ nút Xóa)
document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
        if (!window.confirm(form.dataset.confirm)) {
            event.preventDefault();
        }
    });
});

// Trang đăng ký: đổi nhãn "Mã sinh viên / Lớp" thành "Mã giảng viên / Khoa" theo vai trò
var roleSelect = document.getElementById('role');
if (roleSelect && document.getElementById('code-label')) {
    var updateLabels = function () {
        var isTeacher = roleSelect.value === 'teacher';
        document.getElementById('code-label').textContent = isTeacher ? 'Mã giảng viên' : 'Mã sinh viên';
        document.getElementById('extra-label').textContent = isTeacher ? 'Khoa / Bộ môn' : 'Lớp';
    };
    roleSelect.addEventListener('change', updateLabels);
    updateLabels();
}
