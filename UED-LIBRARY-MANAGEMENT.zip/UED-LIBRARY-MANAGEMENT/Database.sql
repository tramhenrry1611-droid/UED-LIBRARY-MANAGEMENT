
-- ==========================================
-- 1. TAO DATABASE
-- ==========================================

CREATE DATABASE IF NOT EXISTS ued_library
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE ued_library;

-- ==========================================
-- 2. BANG NGUOI DUNG
-- ==========================================

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    role ENUM('admin', 'student', 'teacher', 'librarian') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 3. BANG SINH VIEN
-- ==========================================

CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    student_code VARCHAR(30) NOT NULL UNIQUE,
    class_name VARCHAR(50),

    FOREIGN KEY (user_id)
    REFERENCES users(user_id)
    ON DELETE CASCADE
);

-- ==========================================
-- 4. BANG GIANG VIEN
-- ==========================================

CREATE TABLE teachers (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    teacher_code VARCHAR(30) NOT NULL UNIQUE,
    department VARCHAR(100),

    FOREIGN KEY (user_id)
    REFERENCES users(user_id)
    ON DELETE CASCADE
);

-- ==========================================
-- 5. BANG DANH MUC SACH
-- ==========================================

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT
);

-- ==========================================
-- 6. BANG SACH
-- ==========================================

CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    book_code VARCHAR(30) UNIQUE,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(150),
    publisher VARCHAR(150),
    publish_year INT,
    quantity INT NOT NULL DEFAULT 0,
    quantity_available INT NOT NULL DEFAULT 0,
    description TEXT,

    FOREIGN KEY (category_id)
    REFERENCES categories(category_id)
    ON DELETE SET NULL,

    CHECK (quantity >= 0),
    CHECK (quantity_available >= 0),
    CHECK (quantity_available <= quantity)
);

-- ==========================================
-- 7. BANG PHIEU MUON SACH
-- NHIEM VU 3 - BORROW
-- ==========================================

CREATE TABLE borrows (
    borrow_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    book_id INT NOT NULL,
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    status ENUM(
        'pending',
        'approved',
        'rejected',
        'returned'
    ) NOT NULL DEFAULT 'pending',
    note TEXT,
    approved_by INT NULL,
    approved_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (student_id)
    REFERENCES students(student_id),

    FOREIGN KEY (book_id)
    REFERENCES books(book_id),

    FOREIGN KEY (approved_by)
    REFERENCES users(user_id),

    CHECK (due_date >= borrow_date)
);

-- ==========================================
-- 8. BANG TRA SACH
-- NHIEM VU 4 - RETURN
-- ==========================================

CREATE TABLE return_books (
    return_id INT AUTO_INCREMENT PRIMARY KEY,
    borrow_id INT NOT NULL UNIQUE,
    return_date DATE NOT NULL,
    condition_note TEXT,
    handled_by INT,

    FOREIGN KEY (borrow_id)
    REFERENCES borrows(borrow_id),

    FOREIGN KEY (handled_by)
    REFERENCES users(user_id)
);

-- ==========================================
-- 9. KIEM TRA CAC BANG
-- ==========================================

SHOW TABLES;
